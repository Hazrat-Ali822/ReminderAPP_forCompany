from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from reminders.views import UserViewSet, TaskViewSet, TaskApproveView, LoginView

# Create a router to automatically handle viewset URLs
router = DefaultRouter()
router.register(r'users', UserViewSet)
router.register(r'tasks', TaskViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/v1/auth/login/', LoginView.as_view(), name='login'),
    path('api/v1/', include(router.urls)),
    path('api/v1/tasks/<int:task_id>/approve/', TaskApproveView.as_view(), name='task-approve'),
]
from rest_framework import permissions

class IsSuperAdminOrAdmin(permissions.BasePermission):
    """
    Custom permission to allow access only to Super Admins and Admins.
    """
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        
        return request.user.role in ['Super Admin', 'Admin']

class IsSuperAdmin(permissions.BasePermission):
    """
    Custom permission to allow access only to Super Admins.
    """
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        
        return request.user.role == 'Super Admin'

class IsAdminOrHigher(permissions.BasePermission):
    """
    Custom permission for actions requiring Admin or higher role.
    """
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        
        return request.user.role in ['Super Admin', 'Admin']

class IsTaskOwner(permissions.BasePermission):
    """
    Custom permission to check if the user is the owner of the task.
    """
    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed to any user, so we'll always allow GET, HEAD, or OPTIONS requests.
        if request.method in permissions.SAFE_METHODS:
            return True

        # Write permissions are only allowed to the owner of the snippet.
        return obj.createdByUserId == request.user
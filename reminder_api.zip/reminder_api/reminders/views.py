from django.shortcuts import get_object_or_404
from django.db.models import Q
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken

from .models import User, Task
from .serializers import UserSerializer, TaskSerializer
from .permissions import IsSuperAdminOrAdmin, IsSuperAdmin, IsAdminOrHigher, IsTaskOwner


class UserViewSet(viewsets.ModelViewSet):
    """
    A ViewSet for managing users.
    Permissions are based on the user's role.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'Super Admin':
            return User.objects.all()
        elif user.role == 'Admin':
            # FIX: Admin sees only HR/Manager they created
            return User.objects.filter(created_by=user, role__in=['HR', 'Manager'])
        else:
            return User.objects.filter(id=user.id)

    def get_permissions(self):
        if self.action == 'create':
            self.permission_classes = [IsSuperAdminOrAdmin]
        elif self.action in ['update', 'partial_update', 'destroy']:
            self.permission_classes = [IsSuperAdmin]  # Only Super Admin can edit/delete users
        else:
            self.permission_classes = [IsAuthenticated]
        return super().get_permissions()

    # FIX: proper DRF create (perform_create should not return a Response)
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user_role = serializer.validated_data.get('role')
        if user_role not in ['HR', 'Manager'] and request.user.role == 'Admin':
            return Response({'detail': 'Admin can only create HR or Manager accounts.'},
                            status=status.HTTP_403_FORBIDDEN)

        password = request.data.get('password')
        new_user = User.objects.create_user(
            username=serializer.validated_data.get('username'),
            email=serializer.validated_data.get('email'),
            password=password,
            role=user_role,
            created_by=request.user
        )
        out = self.serializer_class(new_user)
        headers = self.get_success_headers(out.data)
        return Response(out.data, status=status.HTTP_201_CREATED, headers=headers)


class TaskViewSet(viewsets.ModelViewSet):
    """
    A ViewSet for managing tasks.
    The queryset and permissions depend on the user's role.
    """
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        status_filter = self.request.query_params.get('status')
        approved_by_me = self.request.query_params.get('approved_by_me')
        deadline = self.request.query_params.get('deadline')  # NEW

        # Determine base queryset by role
        if user.role == 'Super Admin':
            queryset = Task.objects.all()
        elif user.role == 'Admin':
            managed_users = User.objects.filter(created_by=user)
            queryset = Task.objects.filter(Q(createdByUserId__in=managed_users) | Q(approvedByUserId=user))
        elif user.role in ['HR', 'Manager']:
            queryset = Task.objects.filter(createdByUserId=user)
        else:
            queryset = Task.objects.none()

        # Optional filters
        if approved_by_me == 'true':
            queryset = queryset.filter(approvedByUserId=user)

        if status_filter:
            queryset = queryset.filter(status=status_filter)

        # NEW: filter by exact deadline date (YYYY-MM-DD)
        if deadline:
            queryset = queryset.filter(deadline=deadline)

        return queryset

    def perform_create(self, serializer):
        user = self.request.user
        task_status = 'Approved' if user.role in ['Super Admin', 'Admin'] else 'Pending'  # FIX: avoid name shadowing

        serializer.save(
            createdByUserId=user,
            status=task_status,
            approvedByUserId=user if user.role in ['Super Admin', 'Admin'] else None
        )

    def get_permissions(self):
        """
        Set permissions for different actions on tasks.
        NOTE: If your OR logic isn't supported by your custom classes,
        implement a single permission that returns True for either case.
        """
        if self.action in ['update', 'partial_update', 'destroy']:
            self.permission_classes = [IsSuperAdminOrAdmin | IsTaskOwner]
        else:
            self.permission_classes = [IsAuthenticated]
        return super().get_permissions()


class TaskApproveView(APIView):
    """
    API view to approve a pending task.
    """
    permission_classes = [IsAdminOrHigher]

    def post(self, request, task_id):
        task = get_object_or_404(Task, id=task_id)
        user = request.user

        if task.status == 'Approved':
            return Response({'detail': 'Task is already approved.'}, status=status.HTTP_400_BAD_REQUEST)

        task.status = 'Approved'
        task.approvedByUserId = user
        task.save()

        serializer = TaskSerializer(task)
        return Response(serializer.data, status=status.HTTP_200_OK)


class LoginView(APIView):
    """
    API view for user login. Returns an access token on success.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        if not username or not password:
            return Response({'detail': 'Username and password are required.'}, status=status.HTTP_400_BAD_REQUEST)

        user = get_object_or_404(User, username=username)

        if not user.check_password(password):
            return Response({'detail': 'Invalid credentials.'}, status=status.HTTP_401_UNAUTHORIZED)

        refresh = RefreshToken.for_user(user)
        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'role': user.role,
            'username': user.username,
        })

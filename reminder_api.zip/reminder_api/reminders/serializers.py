from rest_framework import serializers
from .models import User, Task

class UserSerializer(serializers.ModelSerializer):
    """
    Serializer for the User model.
    Includes the 'password' field for creating a new user, marked as write-only.
    """
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'password', 'role']
        read_only_fields = ['id']

class TaskSerializer(serializers.ModelSerializer):
    """
    Serializer for the Task model.
    It uses SlugRelatedField to display usernames instead of IDs.
    """
    createdByUserId = serializers.SlugRelatedField(
        slug_field='username',
        read_only=True
    )
    approvedByUserId = serializers.SlugRelatedField(
        slug_field='username',
        read_only=True,
        allow_null=True
    )

    class Meta:
        model = Task
        fields = '__all__'
        read_only_fields = ['id', 'status', 'createdByUserId', 'approvedByUserId']

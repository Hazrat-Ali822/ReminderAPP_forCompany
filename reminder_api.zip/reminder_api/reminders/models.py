from django.db import models
from django.contrib.auth.models import AbstractUser

# Define choices for the user's role
ROLE_CHOICES = (
    ('Super Admin', 'Super Admin'),
    ('Admin', 'Admin'),
    ('HR', 'HR'),
    ('Manager', 'Manager'),
)

class User(AbstractUser):
    """
    Custom User model to include a 'role' field.
    Extends Django's built-in AbstractUser for authentication.
    """
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='HR')
    # Add a ForeignKey to track which user created this account
    created_by = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_users'
    )
    # Add related_name to avoid clashes with Django's built-in groups and user_permissions
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='custom_user_groups',
        blank=True,
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='custom_user_permissions',
        blank=True,
    )

class Task(models.Model):
    """
    Model for a task with all the required fields.
    It links to the User who created it and the user who approved it.
    """
    PRIORITY_CHOICES = (
        ('High', 'High'),
        ('Medium', 'Medium'),
        ('Low', 'Low'),
    )

    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Completed', 'Completed'),
    )
    
    title = models.CharField(max_length=255)
    description = models.TextField()
    deadline = models.DateField()
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='Low')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')
    
    # ForeignKey relationships to link to the User model
    createdByUserId = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='created_tasks',
        verbose_name='Created By User'
    )
    approvedByUserId = models.ForeignKey(
        User,
        on_delete=models.SET_NULL, # If the approver is deleted, set this field to null
        related_name='approved_tasks',
        null=True,
        blank=True,
        verbose_name='Approved By User'
    )

    def __str__(self):
        return self.title
